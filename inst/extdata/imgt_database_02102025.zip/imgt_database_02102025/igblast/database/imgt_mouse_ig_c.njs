{
  "version": "1.2",
  "dbname": "imgt_mouse_ig_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_mouse_ig_c.fasta",
  "number-of-letters": 37870,
  "number-of-sequences": 42,
  "last-updated": "2025-10-02T13:41:00",
  "number-of-volumes": 1,
  "bytes-total": 62860,
  "bytes-to-cache": 10148,
  "files": [
    "imgt_mouse_ig_c.ndb",
    "imgt_mouse_ig_c.nhr",
    "imgt_mouse_ig_c.nin",
    "imgt_mouse_ig_c.nog",
    "imgt_mouse_ig_c.nos",
    "imgt_mouse_ig_c.not",
    "imgt_mouse_ig_c.nsq",
    "imgt_mouse_ig_c.ntf",
    "imgt_mouse_ig_c.nto"
  ]
}
