{
  "version": "1.2",
  "dbname": "imgt_mouse_tr_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_mouse_tr_d.fasta",
  "number-of-letters": 60,
  "number-of-sequences": 5,
  "last-updated": "2025-10-02T13:41:00",
  "number-of-volumes": 1,
  "bytes-total": 49852,
  "bytes-to-cache": 228,
  "files": [
    "imgt_mouse_tr_d.ndb",
    "imgt_mouse_tr_d.nhr",
    "imgt_mouse_tr_d.nin",
    "imgt_mouse_tr_d.nog",
    "imgt_mouse_tr_d.nos",
    "imgt_mouse_tr_d.not",
    "imgt_mouse_tr_d.nsq",
    "imgt_mouse_tr_d.ntf",
    "imgt_mouse_tr_d.nto"
  ]
}
