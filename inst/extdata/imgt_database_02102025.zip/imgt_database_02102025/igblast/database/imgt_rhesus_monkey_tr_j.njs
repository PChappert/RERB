{
  "version": "1.2",
  "dbname": "imgt_rhesus_monkey_tr_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_rhesus_monkey_tr_j.fasta",
  "number-of-letters": 6207,
  "number-of-sequences": 106,
  "last-updated": "2025-10-02T13:41:00",
  "number-of-volumes": 1,
  "bytes-total": 61394,
  "bytes-to-cache": 3054,
  "files": [
    "imgt_rhesus_monkey_tr_j.ndb",
    "imgt_rhesus_monkey_tr_j.nhr",
    "imgt_rhesus_monkey_tr_j.nin",
    "imgt_rhesus_monkey_tr_j.nog",
    "imgt_rhesus_monkey_tr_j.nos",
    "imgt_rhesus_monkey_tr_j.not",
    "imgt_rhesus_monkey_tr_j.nsq",
    "imgt_rhesus_monkey_tr_j.ntf",
    "imgt_rhesus_monkey_tr_j.nto"
  ]
}
