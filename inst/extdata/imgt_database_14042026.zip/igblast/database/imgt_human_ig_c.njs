{
  "version": "1.2",
  "dbname": "imgt_human_ig_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_human_ig_c.fasta",
  "number-of-letters": 127008,
  "number-of-sequences": 125,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 93153,
  "bytes-to-cache": 33477,
  "files": [
    "imgt_human_ig_c.ndb",
    "imgt_human_ig_c.nhr",
    "imgt_human_ig_c.nin",
    "imgt_human_ig_c.nog",
    "imgt_human_ig_c.nos",
    "imgt_human_ig_c.not",
    "imgt_human_ig_c.nsq",
    "imgt_human_ig_c.ntf",
    "imgt_human_ig_c.nto"
  ]
}
