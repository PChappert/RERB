{
  "version": "1.2",
  "dbname": "imgt_human_ig_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_human_ig_d.fasta",
  "number-of-letters": 1192,
  "number-of-sequences": 48,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 54646,
  "bytes-to-cache": 1048,
  "files": [
    "imgt_human_ig_d.ndb",
    "imgt_human_ig_d.nhr",
    "imgt_human_ig_d.nin",
    "imgt_human_ig_d.nog",
    "imgt_human_ig_d.nos",
    "imgt_human_ig_d.not",
    "imgt_human_ig_d.nsq",
    "imgt_human_ig_d.ntf",
    "imgt_human_ig_d.nto"
  ]
}
