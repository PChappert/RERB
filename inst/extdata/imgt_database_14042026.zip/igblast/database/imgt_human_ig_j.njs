{
  "version": "1.2",
  "dbname": "imgt_human_ig_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_human_ig_j.fasta",
  "number-of-letters": 1606,
  "number-of-sequences": 36,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 53230,
  "bytes-to-cache": 1000,
  "files": [
    "imgt_human_ig_j.ndb",
    "imgt_human_ig_j.nhr",
    "imgt_human_ig_j.nin",
    "imgt_human_ig_j.nog",
    "imgt_human_ig_j.nos",
    "imgt_human_ig_j.not",
    "imgt_human_ig_j.nsq",
    "imgt_human_ig_j.ntf",
    "imgt_human_ig_j.nto"
  ]
}
