{
  "version": "1.2",
  "dbname": "imgt_human_tr_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_human_tr_c.fasta",
  "number-of-letters": 12310,
  "number-of-sequences": 23,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 54660,
  "bytes-to-cache": 3528,
  "files": [
    "imgt_human_tr_c.ndb",
    "imgt_human_tr_c.nhr",
    "imgt_human_tr_c.nin",
    "imgt_human_tr_c.nog",
    "imgt_human_tr_c.nos",
    "imgt_human_tr_c.not",
    "imgt_human_tr_c.nsq",
    "imgt_human_tr_c.ntf",
    "imgt_human_tr_c.nto"
  ]
}
