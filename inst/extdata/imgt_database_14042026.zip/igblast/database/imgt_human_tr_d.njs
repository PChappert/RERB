{
  "version": "1.2",
  "dbname": "imgt_human_tr_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_human_tr_d.fasta",
  "number-of-letters": 74,
  "number-of-sequences": 6,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 49953,
  "bytes-to-cache": 245,
  "files": [
    "imgt_human_tr_d.ndb",
    "imgt_human_tr_d.nhr",
    "imgt_human_tr_d.nin",
    "imgt_human_tr_d.nog",
    "imgt_human_tr_d.nos",
    "imgt_human_tr_d.not",
    "imgt_human_tr_d.nsq",
    "imgt_human_tr_d.ntf",
    "imgt_human_tr_d.nto"
  ]
}
