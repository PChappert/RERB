{
  "version": "1.2",
  "dbname": "imgt_human_tr_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_human_tr_j.fasta",
  "number-of-letters": 5908,
  "number-of-sequences": 101,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 60785,
  "bytes-to-cache": 2899,
  "files": [
    "imgt_human_tr_j.ndb",
    "imgt_human_tr_j.nhr",
    "imgt_human_tr_j.nin",
    "imgt_human_tr_j.nog",
    "imgt_human_tr_j.nos",
    "imgt_human_tr_j.not",
    "imgt_human_tr_j.nsq",
    "imgt_human_tr_j.ntf",
    "imgt_human_tr_j.nto"
  ]
}
