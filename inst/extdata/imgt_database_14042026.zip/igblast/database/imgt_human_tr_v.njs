{
  "version": "1.2",
  "dbname": "imgt_human_tr_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_human_tr_v.fasta",
  "number-of-letters": 100094,
  "number-of-sequences": 355,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 122401,
  "bytes-to-cache": 29645,
  "files": [
    "imgt_human_tr_v.ndb",
    "imgt_human_tr_v.nhr",
    "imgt_human_tr_v.nin",
    "imgt_human_tr_v.nog",
    "imgt_human_tr_v.nos",
    "imgt_human_tr_v.not",
    "imgt_human_tr_v.nsq",
    "imgt_human_tr_v.ntf",
    "imgt_human_tr_v.nto"
  ]
}
