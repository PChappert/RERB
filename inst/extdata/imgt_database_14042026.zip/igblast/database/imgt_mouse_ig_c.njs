{
  "version": "1.2",
  "dbname": "imgt_mouse_ig_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_mouse_ig_c.fasta",
  "number-of-letters": 42986,
  "number-of-sequences": 43,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 64228,
  "bytes-to-cache": 11434,
  "files": [
    "imgt_mouse_ig_c.ndb",
    "imgt_mouse_ig_c.nhr",
    "imgt_mouse_ig_c.nin",
    "imgt_mouse_ig_c.nog",
    "imgt_mouse_ig_c.nos",
    "imgt_mouse_ig_c.not",
    "imgt_mouse_ig_c.nsq",
    "imgt_mouse_ig_c.ntf",
    "imgt_mouse_ig_c.nto"
  ]
}
