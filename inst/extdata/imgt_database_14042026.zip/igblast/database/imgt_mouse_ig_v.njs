{
  "version": "1.2",
  "dbname": "imgt_mouse_ig_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_mouse_ig_v.fasta",
  "number-of-letters": 249015,
  "number-of-sequences": 859,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 225456,
  "bytes-to-cache": 73266,
  "files": [
    "imgt_mouse_ig_v.ndb",
    "imgt_mouse_ig_v.nhr",
    "imgt_mouse_ig_v.nin",
    "imgt_mouse_ig_v.nog",
    "imgt_mouse_ig_v.nos",
    "imgt_mouse_ig_v.not",
    "imgt_mouse_ig_v.nsq",
    "imgt_mouse_ig_v.ntf",
    "imgt_mouse_ig_v.nto"
  ]
}
