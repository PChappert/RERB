{
  "version": "1.2",
  "dbname": "imgt_mouse_tr_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_mouse_tr_c.fasta",
  "number-of-letters": 6705,
  "number-of-sequences": 13,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 52321,
  "bytes-to-cache": 2029,
  "files": [
    "imgt_mouse_tr_c.ndb",
    "imgt_mouse_tr_c.nhr",
    "imgt_mouse_tr_c.nin",
    "imgt_mouse_tr_c.nog",
    "imgt_mouse_tr_c.nos",
    "imgt_mouse_tr_c.not",
    "imgt_mouse_tr_c.nsq",
    "imgt_mouse_tr_c.ntf",
    "imgt_mouse_tr_c.nto"
  ]
}
