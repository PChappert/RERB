{
  "version": "1.2",
  "dbname": "imgt_mouse_tr_j",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_mouse_tr_j.fasta",
  "number-of-letters": 5590,
  "number-of-sequences": 96,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 60218,
  "bytes-to-cache": 2754,
  "files": [
    "imgt_mouse_tr_j.ndb",
    "imgt_mouse_tr_j.nhr",
    "imgt_mouse_tr_j.nin",
    "imgt_mouse_tr_j.nog",
    "imgt_mouse_tr_j.nos",
    "imgt_mouse_tr_j.not",
    "imgt_mouse_tr_j.nsq",
    "imgt_mouse_tr_j.ntf",
    "imgt_mouse_tr_j.nto"
  ]
}
