{
  "version": "1.2",
  "dbname": "imgt_rhesus_monkey_ig_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_rhesus_monkey_ig_c.fasta",
  "number-of-letters": 24643,
  "number-of-sequences": 30,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 58404,
  "bytes-to-cache": 6702,
  "files": [
    "imgt_rhesus_monkey_ig_c.ndb",
    "imgt_rhesus_monkey_ig_c.nhr",
    "imgt_rhesus_monkey_ig_c.nin",
    "imgt_rhesus_monkey_ig_c.nog",
    "imgt_rhesus_monkey_ig_c.nos",
    "imgt_rhesus_monkey_ig_c.not",
    "imgt_rhesus_monkey_ig_c.nsq",
    "imgt_rhesus_monkey_ig_c.ntf",
    "imgt_rhesus_monkey_ig_c.nto"
  ]
}
