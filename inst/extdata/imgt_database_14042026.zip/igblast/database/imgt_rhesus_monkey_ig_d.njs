{
  "version": "1.2",
  "dbname": "imgt_rhesus_monkey_ig_d",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_rhesus_monkey_ig_d.fasta",
  "number-of-letters": 1342,
  "number-of-sequences": 60,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 55837,
  "bytes-to-cache": 1257,
  "files": [
    "imgt_rhesus_monkey_ig_d.ndb",
    "imgt_rhesus_monkey_ig_d.nhr",
    "imgt_rhesus_monkey_ig_d.nin",
    "imgt_rhesus_monkey_ig_d.nog",
    "imgt_rhesus_monkey_ig_d.nos",
    "imgt_rhesus_monkey_ig_d.not",
    "imgt_rhesus_monkey_ig_d.nsq",
    "imgt_rhesus_monkey_ig_d.ntf",
    "imgt_rhesus_monkey_ig_d.nto"
  ]
}
