{
  "version": "1.2",
  "dbname": "imgt_rhesus_monkey_ig_v",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_rhesus_monkey_ig_v.fasta",
  "number-of-letters": 204526,
  "number-of-sequences": 692,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 192336,
  "bytes-to-cache": 60052,
  "files": [
    "imgt_rhesus_monkey_ig_v.ndb",
    "imgt_rhesus_monkey_ig_v.nhr",
    "imgt_rhesus_monkey_ig_v.nin",
    "imgt_rhesus_monkey_ig_v.nog",
    "imgt_rhesus_monkey_ig_v.nos",
    "imgt_rhesus_monkey_ig_v.not",
    "imgt_rhesus_monkey_ig_v.nsq",
    "imgt_rhesus_monkey_ig_v.ntf",
    "imgt_rhesus_monkey_ig_v.nto"
  ]
}
