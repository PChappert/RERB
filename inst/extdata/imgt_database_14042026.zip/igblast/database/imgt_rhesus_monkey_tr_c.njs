{
  "version": "1.2",
  "dbname": "imgt_rhesus_monkey_tr_c",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/Users/pascal/share/igblast/fasta/imgt_rhesus_monkey_tr_c.fasta",
  "number-of-letters": 4894,
  "number-of-sequences": 10,
  "last-updated": "2026-04-14T13:35:00",
  "number-of-volumes": 1,
  "bytes-total": 51588,
  "bytes-to-cache": 1554,
  "files": [
    "imgt_rhesus_monkey_tr_c.ndb",
    "imgt_rhesus_monkey_tr_c.nhr",
    "imgt_rhesus_monkey_tr_c.nin",
    "imgt_rhesus_monkey_tr_c.nog",
    "imgt_rhesus_monkey_tr_c.nos",
    "imgt_rhesus_monkey_tr_c.not",
    "imgt_rhesus_monkey_tr_c.nsq",
    "imgt_rhesus_monkey_tr_c.ntf",
    "imgt_rhesus_monkey_tr_c.nto"
  ]
}
